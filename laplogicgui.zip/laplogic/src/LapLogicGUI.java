import javax.swing.*;
import java.awt.*;

public class LapLogicGUI {

    public static void main(String[] args) {
        //dhmiourgia tou frame
        JFrame frame = new JFrame("LapLogic");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(600, 400);
        //to logo panw aristera sto parathiro
        ImageIcon image = new ImageIcon("C:\\Users\\stefo\\Desktop\\logo transp1.png");
        frame.setIconImage(image.getImage());
        // dhmiourgia tou fountou
        JPanel panel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g;
                int width = getWidth();
                int height = getHeight();
                Color color1 = new Color(128, 128, 128);
                Color color2 = new Color(190, 101, 79);
                GradientPaint gp = new GradientPaint(0, 0, color1, 0, height, color2);
                g2d.setPaint(gp);
                g2d.fillRect(0, 0, width, height);
            }
        };
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));

        // eisagwgh tou logo
        JLabel logoLabel = new JLabel(new ImageIcon("C:\\Users\\stefo\\Desktop\\logo transp1.png"));
        logoLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        panel.add(Box.createRigidArea(new Dimension(0, 50)));
        panel.add(logoLabel);

        // welcome label
        JLabel welcomeLabel = new JLabel("Welcome to the world of Motorsports");
        welcomeLabel.setForeground(Color.WHITE);
        welcomeLabel.setFont(new Font("Arial", Font.BOLD, 24));
        welcomeLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        panel.add(Box.createRigidArea(new Dimension(0, 20)));
        panel.add(welcomeLabel);

        // koumpi get started
        JButton getStartedButton = new JButton("Get Started");
        getStartedButton.setForeground(new Color(239, 63, 9));
        getStartedButton.setBackground(new Color(239, 233, 231));
        getStartedButton.setFont(new Font("Arial", Font.BOLD, 18));
        getStartedButton.setFocusPainted(false);
        getStartedButton.setAlignmentX(Component.CENTER_ALIGNMENT);
        panel.add(Box.createRigidArea(new Dimension(0, 20)));
        panel.add(getStartedButton);

        //panel kai orato frame
        frame.add(panel);
        frame.setVisible(true);
    }
}
